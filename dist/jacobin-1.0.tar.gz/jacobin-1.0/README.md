# jacobin
JACOBIN: JAX Compound Binomials, head-counting distributions
